=== Fastr ===
fastr is based on Underscores http://underscores.me/, (C) 2012-2013 Automattic, Inc.

== Changelog ==

= 1.2.0.0 - Jan 19 2014 =
* Removed unnecessary files
* Sticky post styles updated
* Fixed Tier 2 sub level menus 

= 1.1.0.0 - Jan 1 2014 =
* Fixed few styling issues

= 1.0 - Dec 31 2013 =
* Initial release of Fastr